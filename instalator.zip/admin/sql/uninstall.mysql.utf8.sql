DROP TABLE IF EXISTS `#__repertoire`;
DROP TABLE IF EXISTS `#__repertoire_events`;
DROP TABLE IF EXISTS `#__repertoire_info`;
DROP TABLE IF EXISTS `#__repertoire_songs_events`;

DELETE FROM `#__categories` WHERE extension = "com_repertoire";