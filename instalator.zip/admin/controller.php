<?php
/**
 * @package     Joomla.Administrator
 * @subpackage  com_repertoire
 *
 * @copyright   Copyright (C) 2015 Szymon Michalewicz. All rights reserved.
 */

// Brak bezpośredniego dostępu do pliku
defined('_JEXEC') or die('Restricted access');

/**
 * Component Controller
 *
 * @since  1.5
 */
class RepertoireController extends JControllerLegacy {

    protected $default_view = 'repertoire';

}
