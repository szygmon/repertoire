<?php
// Brak bezpośredniego dostępu do pliku
defined('_JEXEC') or die('Restricted access');

class RepertoireController extends JControllerLegacy {

    protected $default_view = 'repertoire';

}
